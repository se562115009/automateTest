(function() {
  'use strict';

  angular
    .module('app', ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'ngMessages'
      ,'ngAria', 'ngResource', 'ui.router', 'ui.bootstrap', 'toastr','ngResource+apiPrefix'
      ,'schemaForm']);


})();
