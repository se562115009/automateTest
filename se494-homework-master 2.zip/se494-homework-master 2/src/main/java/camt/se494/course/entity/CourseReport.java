package camt.se494.course.entity;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Dto on 10/1/2015.
 */
@Builder
@Setter
@Getter
@Entity
public class CourseReport {
    Course course;

    //default constructor
    public CourseReport() {
    }

    //constroctor
    public CourseReport(Course course, List<Student> students, double averageGpa, double totalStudent) {
        this.course = course;
        this.students = students;
        this.averageGpa = averageGpa;
        this.totalStudent = totalStudent;
    }

    public Course getCourse() {return course;}

    public void setCourse(Course course) {
        this.course = course;
    }

    List<Student> students  = new ArrayList<Student>();
    double averageGpa;
    double totalStudent;

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public double getAverageGpa() {
        return averageGpa;
    }

    public void setAverageGpa(double averageGpa) {
        this.averageGpa = averageGpa;
    }

    public double getTotalStudent() {
        return totalStudent;
    }

    public void setTotalStudent(double totalStudent) {
        this.totalStudent = totalStudent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CourseReport that = (CourseReport) o;

        if (Double.compare(that.averageGpa, averageGpa) != 0) return false;
        if (Double.compare(that.totalStudent, totalStudent) != 0) return false;
        if (course != null ? !course.equals(that.course) : that.course != null) return false;
        return students != null ? students.equals(that.students) : that.students == null;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = course != null ? course.hashCode() : 0;
        result = 31 * result + (students != null ? students.hashCode() : 0);
        temp = Double.doubleToLongBits(averageGpa);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(totalStudent);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        return result;
    }
}
