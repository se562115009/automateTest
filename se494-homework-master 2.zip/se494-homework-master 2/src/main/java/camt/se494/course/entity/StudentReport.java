package camt.se494.course.entity;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import java.util.*;

/**
 * Created by Dto on 10/1/2015.
 */

@Builder
@Setter
@Getter
@Entity
public class StudentReport {
    Student student;
    Map<Integer,List<CourseEnrolment>> enrolmentMap = new TreeMap<>();
    Map<Integer,Double> gpaMap = new TreeMap<>();

    // constuctor
    public StudentReport(Student student, Map<Integer, List<CourseEnrolment>> enrolmentMap, Map<Integer, Double> gpaMap) {
        this.student = student;
        this.enrolmentMap = enrolmentMap;
        this.gpaMap = gpaMap;
    }

    //defaualt constructor
    public StudentReport() {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StudentReport that = (StudentReport) o;

        if (student != null ? !student.equals(that.student) : that.student != null) return false;
        if (enrolmentMap != null ? !enrolmentMap.equals(that.enrolmentMap) : that.enrolmentMap != null) return false;
        return gpaMap != null ? gpaMap.equals(that.gpaMap) : that.gpaMap == null;
    }

    @Override
    public int hashCode() {
        int result = student != null ? student.hashCode() : 0;
        result = 31 * result + (enrolmentMap != null ? enrolmentMap.hashCode() : 0);
        result = 31 * result + (gpaMap != null ? gpaMap.hashCode() : 0);
        return result;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Map<Integer, List<CourseEnrolment>> getEnrolmentMap() {
        return enrolmentMap;
    }

    public void setEnrolmentMap(Map<Integer, List<CourseEnrolment>> enrolmentMap) {
        this.enrolmentMap = enrolmentMap;
    }

    public Map<Integer, Double> getGpaMap() {
        return gpaMap;
    }

    public void setGpaMap(Map<Integer, Double> gpaMap) {
        this.gpaMap = gpaMap;
    }
}
