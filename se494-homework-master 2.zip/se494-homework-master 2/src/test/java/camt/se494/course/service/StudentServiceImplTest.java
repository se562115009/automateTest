package camt.se494.course.service;

import camt.se494.course.dao.CourseDao;
import camt.se494.course.dao.CourseEnrolmentDao;
import camt.se494.course.dao.OpenedCourseDao;
import camt.se494.course.dao.StudentDao;
import camt.se494.course.entity.*;
import camt.se494.course.exception.UnAcceptGradeException;
import camt.se494.course.service.util.GradeMatcher;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InOrder;

import javax.validation.GroupDefinitionException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.number.IsCloseTo.*;

/**
 * Created by Dto on 10/2/2015.
 */
public class StudentServiceImplTest {
    StudentServiceImpl studentService;
    CourseEnrolmentDao courseEnrolmentDao;

    CourseServiceImpl courseServic = spy(CourseServiceImpl.class);

    List<CourseEnrolment> courseEnrolments;
    List<OpenedCourse> openedCourses = new ArrayList<>();
    CourseDao courseDao;
    Student s1 = new Student("552115045", "Prayuth CanOcha");
    Student s2 = new Student("552115047", "Suthep Wongkamhang");
    Student s3 = new Student("552115048", "Surayuth Chulanon");
    Student s4 = new Student("552115049", "Taggy Chinosuke");
    Student s5 = new Student("552115022", "YingLove Chinosuke");
    Course c1 = new Course("953494", "Special Topic in Software Engineering");
    Course c2 = new Course("953331", "Component Based Software Development");
    Course c3 = new Course("953201", "Introduction to Algorithm");
    StudentDao studentDao;
    Course c4 = new Course("953202", "Introduction to Software development");
    List<CourseEnrolment> expected = new ArrayList<>();
    List<OpenedCourse> expectedop = new ArrayList<>();
    List<Student> s = new ArrayList<>();
    List<Course> courses = new ArrayList<>();
    OpenedCourseDao openedCourseDao;

    List<CourseEnrolment> courseEnrolmentss = new ArrayList<>();

    @Before
    public void setup() {
        studentService = spy(StudentServiceImpl.class);
        studentDao = spy(StudentDao.class);
        courseEnrolmentDao = spy(CourseEnrolmentDao.class);
        courseDao = spy(CourseDao.class);
        openedCourseDao = spy(OpenedCourseDao.class);
        courseEnrolments = new ArrayList<>();
        studentService.setCourseEnrolmentDao(courseEnrolmentDao);
        studentService.setStudentDao(studentDao);

        courses.add(c1);
        courses.add(c2);
        courses.add(c3);
        courses.add(c4);
        when(courseDao.getCourse()).thenReturn(courses);

        OpenedCourse oc11 = new OpenedCourse(c1, 2558);
        OpenedCourse oc12 = new OpenedCourse(c2, 2558);
        OpenedCourse oc13 = new OpenedCourse(c3, 2558);
        OpenedCourse oc14 = new OpenedCourse(c4, 2558);
        OpenedCourse oc21 = new OpenedCourse(c1, 2557);
        OpenedCourse oc22 = new OpenedCourse(c2, 2557);
        OpenedCourse oc23 = new OpenedCourse(c3, 2557);
        OpenedCourse oc24 = new OpenedCourse(c4, 2557);
        OpenedCourse oc31 = new OpenedCourse(c1, 2556);
        OpenedCourse oc32 = new OpenedCourse(c2, 2556);
        OpenedCourse oc33 = new OpenedCourse(c3, 2556);
        OpenedCourse oc34 = new OpenedCourse(c4, 2556);
        expectedop.add(oc31);
        expectedop.add(oc32);
        expectedop.add(oc33);
        expectedop.add(oc34);

        openedCourses.add(oc12);
        openedCourses.add(oc11);
        openedCourses.add(oc13);
        openedCourses.add(oc14);
        openedCourses.add(oc21);
        openedCourses.add(oc22);
        openedCourses.add(oc23);
        openedCourses.add(oc24);
        openedCourses.add(oc31);
        openedCourses.add(oc32);
        openedCourses.add(oc33);
        openedCourses.add(oc34);
        when(openedCourseDao.getOpenedCourse()).thenReturn(openedCourses);

        CourseEnrolment ce21 = new CourseEnrolment(s2, oc21, "A");
        CourseEnrolment ce22 = new CourseEnrolment(s2, oc32, "B+");
        CourseEnrolment ce23 = new CourseEnrolment(s2, oc13, "C+");
        CourseEnrolment ce24 = new CourseEnrolment(s2, oc14, "A");
        expected.add(ce21);
        courseEnrolmentss.add(ce21);
        courseEnrolmentss.add(ce22);
        courseEnrolmentss.add(ce23);
        courseEnrolmentss.add(ce24);
        s2.setCourseEnrolments(courseEnrolmentss);

        courseEnrolmentss = new ArrayList<>();

        CourseEnrolment ce31 = new CourseEnrolment(s3, oc31, "C+");
        CourseEnrolment ce32 = new CourseEnrolment(s3, oc22, "C+");
        CourseEnrolment ce33 = new CourseEnrolment(s3, oc33, "C+");
        CourseEnrolment ce34 = new CourseEnrolment(s3, oc34, "C+");
        courseEnrolmentss.add(ce31);
        courseEnrolmentss.add(ce32);
        courseEnrolmentss.add(ce33);
        courseEnrolmentss.add(ce34);

        s3.setCourseEnrolments(courseEnrolmentss);

        courseEnrolmentss = new ArrayList<>();

        CourseEnrolment ce41 = new CourseEnrolment(s4, oc11, "B+");
        CourseEnrolment ce42 = new CourseEnrolment(s4, oc12, "A");
        CourseEnrolment ce43 = new CourseEnrolment(s4, oc23, "F");
        CourseEnrolment ce44 = new CourseEnrolment(s4, oc24, "C");
        courseEnrolmentss.add(ce41);
        courseEnrolmentss.add(ce42);
        courseEnrolmentss.add(ce43);
        courseEnrolmentss.add(ce44);

        s4.setCourseEnrolments(courseEnrolmentss);

        courseEnrolmentss = new ArrayList<>();
        CourseEnrolment ce51 = new CourseEnrolment(s5, oc11, "B");
        CourseEnrolment ce52 = new CourseEnrolment(s5, oc12, "F");
        CourseEnrolment ce53 = new CourseEnrolment(s5, oc13, "F");
        CourseEnrolment ce54 = new CourseEnrolment(s5, oc14, "F");
        courseEnrolmentss.add(ce51);
        courseEnrolmentss.add(ce52);
        courseEnrolmentss.add(ce53);
        courseEnrolmentss.add(ce54);

        s5.setCourseEnrolments(courseEnrolmentss);

        courseEnrolmentss.clear();
        courseEnrolments.add(ce21);
        courseEnrolments.add(ce22);
        courseEnrolments.add(ce23);
        courseEnrolments.add(ce24);

        courseEnrolments.add(ce31);
        courseEnrolments.add(ce32);
        courseEnrolments.add(ce33);
        courseEnrolments.add(ce34);

        courseEnrolments.add(ce41);
        courseEnrolments.add(ce42);
        courseEnrolments.add(ce43);
        courseEnrolments.add(ce44);
        courseEnrolments.add(ce51);
        courseEnrolments.add(ce52);
        courseEnrolments.add(ce53);
        courseEnrolments.add(ce54);
        when(courseEnrolmentDao.getCourseEnrolments()).thenReturn(courseEnrolments);
        s = new ArrayList<>();
        s.add(s1);
        s.add(s2);
        s.add(s3);
        s.add(s4);
        s.add(s5);
        when(studentDao.updateStudent(s1)).thenReturn(s1);
    }

    @Test
    public void testGetStudentReport() {
        studentService.setCourseEnrolmentDao(courseEnrolmentDao);
        studentService.setStudentDao(studentDao);
        when(studentService.getRegisterYear(courseEnrolments)).thenReturn(Arrays.asList(2554, 2555, 2556));
        Student student = new Student();
        StudentReport studentReport = studentService.getStudentReport(student);
        assertThat(studentService.getStudentReport(student), is(studentReport));

    }

    @Test
    public void testGetStudentGpa() {
        studentService.setCourseEnrolmentDao(courseEnrolmentDao);
        studentService.setStudentDao(studentDao);
        Student testStudent = mock(Student.class);
        List<CourseEnrolment> enrolmentsList = new ArrayList<>();
        CourseEnrolment courseEnrolment0 = mock(CourseEnrolment.class);
        when(courseEnrolment0.getGrade()).thenReturn("A");
        enrolmentsList.add(courseEnrolment0);
        CourseEnrolment courseEnrolment1 = mock(CourseEnrolment.class);
        when(courseEnrolment1.getGrade()).thenReturn("B");
        enrolmentsList.add(courseEnrolment1);
        CourseEnrolment courseEnrolment2 = mock(CourseEnrolment.class);
        when(courseEnrolment2.getGrade()).thenReturn("C");
        enrolmentsList.add(courseEnrolment2);
        when(testStudent.getCourseEnrolments()).thenReturn(enrolmentsList);
        when(studentDao.updateStudent(testStudent)).thenReturn(testStudent);
        assertThat(studentService.updateStudent(testStudent), is(testStudent));
        GradeMatcher gradeMatcher = mock(GradeMatcher.class);
        when(gradeMatcher.getGradeScore("A")).thenReturn(4.00);
        when(gradeMatcher.getGradeScore("B+")).thenReturn(3.50);
        when(gradeMatcher.getGradeScore("B")).thenReturn(3.00);
        when(gradeMatcher.getGradeScore("C+")).thenReturn(2.50);
        when(gradeMatcher.getGradeScore("C")).thenReturn(2.00);
        when(gradeMatcher.getGradeScore("D+")).thenReturn(1.50);

        when(gradeMatcher.getGradeScore("D")).thenReturn(1.00);

        when(gradeMatcher.getGradeScore("F")).thenReturn(0.00);

        // run the test
        StudentServiceImpl studentService = new StudentServiceImpl();
        studentService.setGradeMatcher(gradeMatcher);
        assertThat(studentService.getStudentGpa(testStudent), is(closeTo(3.00, 0.001)));

        // verify that the grade matcher has been called
        verify(courseEnrolment0).getGrade();
        verify(courseEnrolment1).getGrade();

        // has it receive what should be?
        verify(gradeMatcher).getGradeScore("A");
        verify(gradeMatcher).getGradeScore("B");


        // verify how many times it has been called
        verify(courseEnrolment0, times(1)).getGrade();
        verify(gradeMatcher, times(3)).getGradeScore(anyString());
        verify(gradeMatcher, atLeast(2)).getGradeScore(anyString());

        //Check the order
        // set up the inorder verification
        InOrder inOrder = inOrder(courseEnrolment0, courseEnrolment1, courseEnrolment2, gradeMatcher);
        inOrder.verify(courseEnrolment0).getGrade();
        inOrder.verify(gradeMatcher).getGradeScore("A");
        inOrder.verify(courseEnrolment1).getGrade();
        inOrder.verify(gradeMatcher).getGradeScore("B");

        studentService.setGradeMatcher(null);


    }

    @Test
    public void testStudent() {
        when(studentDao.getStudent()).thenReturn(s);
        StudentReport studentReport;
        when(courseEnrolmentDao.getCourseEnrolments(s2)).thenReturn(s2.getCourseEnrolments());
        studentReport = studentService.getStudentReport(s2);
        assertThat(studentService.getStudentReport(s2), is(studentReport));
        when(courseDao.getCourse()).thenReturn(courses);
        GradeMatcher gradeMatcher = spy(GradeMatcher.class);
//        when(gradeMatcher.getGradeScore("DD")).thenThrow(new UnAcceptGradeException());
        assertThat(gradeMatcher.getGradeScore("A"), is(4.00));
        assertThat(gradeMatcher.getGradeScore("B+"), is(3.50));
        assertThat(gradeMatcher.getGradeScore("B"), is(3.00));
        assertThat(gradeMatcher.getGradeScore("C+"), is(2.50));
        assertThat(gradeMatcher.getGradeScore("C"), is(2.00));
        assertThat(gradeMatcher.getGradeScore("D+"), is(1.50));
        assertThat(gradeMatcher.getGradeScore("D"), is(1.00));
        assertThat(gradeMatcher.getGradeScore("F"), is(0.00));


        //s4 2558 A B+ oc11, oc12
        assertThat(studentService.getStudentGpa(s4, 2558), is(3.75));
        s4.setCourseEnrolments(courseEnrolmentss);
        studentService.setGradeMatcher(gradeMatcher);
        when(courseEnrolmentDao.getCourseEnrolments(s4)).thenReturn(courseEnrolmentss);
        double gpa = studentService.getStudentGpa(s4);
        studentReport = studentService.getStudentReport(s4);

        when(studentDao.updateStudent(s1)).thenReturn(s1);
        assertThat(studentService.updateStudent(s1), is(s1));
        assertThat(studentService.getStudent(), is(s));
        assertThat(studentService.getRegisterYear(courseEnrolments), hasItems(2556));
        assertThat(studentService.getRegisterYear(courseEnrolments), hasItems(2557));
        assertThat(studentService.getRegisterYear(courseEnrolments), hasItems(2558));
        assertThat(studentService.getStudentGradeGreaterThan(2.2), hasItem(s3));
        assertThat(studentService.getStudentGradeLowerThan(4.0), hasItem(s3));

//        assertThat(studentService.getStudentGradeGreaterThan(3.2));
        List<Student> test = new ArrayList<>();
        test.add(s2);
        when(studentDao.getStudent("Suthep")).thenReturn(test);

        assertThat(studentService.getStudent("Suthep"), hasItem(s2));
        System.out.print("Test");

        studentService.setGradeMatcher(gradeMatcher);

        try {
            assertThat(gradeMatcher.getGradeScore("DD"), is(1.0));

        } catch (UnAcceptGradeException e) {

        } catch (Exception e) {

        }
        studentService.setGradeMatcher(null);
        try {
            assertThat(studentService.getStudent(), is(s));
        } catch (RuntimeException e) {

        }

    }

    @Test
    public void TestCoreseService() {

        courseServic.setCourseDao(courseDao);
        courseServic.setCourseEnrolmentDao(courseEnrolmentDao);
        courseServic.setOpenedCourseDao(openedCourseDao);

//       Double test=courseServic.getCourseGpa(courseEnrolments);
        assertThat(courseServic.getCourseGpa(courseEnrolments), closeTo(2.285, 0.01));
        when(courseEnrolmentDao.getCourseEnrolments(c1, 2557)).thenReturn(expected);
        when(openedCourseDao.getOpenedCourse(2556)).thenReturn(expectedop);
        CourseReport asset = new CourseReport();
        asset.setAverageGpa(4.0);
        asset.setTotalStudent(1.0);
        asset.setCourse(c1);
        asset.getStudents().add(s2);
        assertThat(courseServic.getCourseReport(c1, 2557), is(asset));
        List<Course> example=courseServic.getCourse(c1.getCourseName(),2556);
        assertThat(courseServic.getCourse(c1.getCourseName(),2556),hasItem(c1));
        when(courseDao.getCourse("953494")).thenReturn(example);
        assertThat(courseServic.getCourseFromIdOrName("953494"),hasItem(c1));
        assertThat(courseServic.getCourse("953494"),is(example));
        assertThat(courseServic.getCourse(),is(courses));
        assertThat(courseServic.getCourseFromIdOrName(""),is(courses));
        example=courseServic.getCourse(2556);
        assertThat(courseServic.getCourse(2556),is(courses));

    }
}
